package com.example.carapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Baleno extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_baleno);
    }
}
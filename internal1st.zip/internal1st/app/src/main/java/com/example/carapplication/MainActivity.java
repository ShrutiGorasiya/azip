package com.example.carapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    ListView listDep;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listDep =findViewById(R.id.listdept);
        String[] cars = {"Baleno","Volvo"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_dropdown_item_1line,cars);
        listDep.setAdapter(adapter);
        listDep.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if(cars[i].equals("Baleno"))
                {
                    Intent i1 = new
                            Intent(MainActivity.this, Baleno.class);
                    startActivity(i1);
                    Toast.makeText(MainActivity.this,
                            "Baleno Selected",
                            Toast.LENGTH_SHORT).show();
                }
              else
                if(cars[i].equals("Volvo"))
                {
                    Intent i1 = new
                            Intent(MainActivity.this, Volvo.class);
                    startActivity(i1);
                    Toast.makeText(MainActivity.this,
                            "Volvo Selected",
                            Toast.LENGTH_SHORT).show();
                }

            }
        });

    }
}
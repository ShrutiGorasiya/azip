package com.example.crud_priya;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class showAllActivity extends AppCompatActivity {
    dbo obj = new dbo(this,null,null,1);
    private ArrayList<String> arraylist=new ArrayList<String>();
    private ArrayAdapter<String> adapter;
    Button search;
    EditText EditText1;
    ListView lv;
    @SuppressLint("Range")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_all);
        EditText1=findViewById(R.id.EditText1);
        search=findViewById(R.id.search);
        ListView lv;
        List<String> ls = new ArrayList<>();
        List<String> fls = new ArrayList<>();
        lv=findViewById(R.id.lv1);

//        Cursor c;
//        c=obj.get_Data();
//        if(c != null && !c.isClosed())
//        {
//            c.moveToFirst();
//            do{
//                ls.add(c.getString(c.getColumnIndex("ename")).toString());
//                fls.add(c.getString(c.getColumnIndex("fname")).toString());
//            }while (c.moveToNext());
//            ArrayAdapter<String> adp=new ArrayAdapter<>(this, R.layout.support_simple_spinner_dropdown_item, ls);
//            lv.setAdapter(adp);
//        }
//        else
//        {
//            Toast.makeText(getApplicationContext(),"No Data", Toast.LENGTH_LONG).show();
//        }
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor c1;
                c1 = obj.populateListview(EditText1.getText().toString());
                if (c1 != null && !c1.isClosed()) {
                    c1.moveToFirst();
                    do {
                        ls.add(c1.getString(c1.getColumnIndex("ename")).toString());
                        fls.add(c1.getString(c1.getColumnIndex("fname")).toString());
                    } while (c1.moveToNext());
                    ArrayAdapter<String> adp = new ArrayAdapter<>(showAllActivity.this, R.layout.support_simple_spinner_dropdown_item, ls);
                    lv.setAdapter(adp);
                } else {
                    Toast.makeText(getApplicationContext(), "No Data", Toast.LENGTH_LONG).show();
                }
            }
        });
//       EditText1.addTextChangedListener(new TextWatcher() {
//           @Override
//           public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//
//           }
//
//           @Override
//           public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//
//           }
//
//           @Override
//           public void afterTextChanged(Editable editable) {
//
//           }
//       });





//        List<String> ls = new ArrayList<>();
//        List<String> fls = new ArrayList<>();
//        lv=findViewById(R.id.lv1);
//
//        EditText1=findViewById(R.id.editText1);
//        Cursor c;
//        c=obj.get_Data();
//        if(c != null && !c.isClosed())
//        {
//            c.moveToFirst();
//            do{
//                ls.add(c.getString(c.getColumnIndex("ename")).toString());
//                fls.add(c.getString(c.getColumnIndex("fname")).toString());
//                String ename = c.getString(c.getColumnIndex("ename"));
//                String fname = c.getString(c.getColumnIndex("fname"));
//
//                arraylist.add("Name :" + ename + "\n" + "Age :" + fname + "\n");
//            }while (c.moveToNext());
//
////            ArrayAdapter<String> adp=new ArrayAdapter<>(this, R.layout.support_simple_spinner_dropdown_item, ls);
////            lv.setAdapter(adp);
//            ArrayAdapter<String> adp=new ArrayAdapter<String>(showAllActivity.this, R.layout.support_simple_spinner_dropdown_item,arraylist);
//                   lv.setAdapter(adp);
//        }
//        else
//        {
//            Toast.makeText(getApplicationContext(),"No Data", Toast.LENGTH_LONG).show();
//        }
//        EditText1.addTextChangedListener(new TextWatcher() {
//           @Override
//           public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//
//           }
//
//           @Override
//           public void onTextChanged(CharSequence s, int i, int i1, int i2) {
//
//                   try {
//                       Cursor c=obj.populateListview((String) s);
//                       if (c != null) {
//                           if (c.moveToFirst()) {
//                               do {
//                             ls.add(c.getString(c.getColumnIndex("ename")).toString());
////                             fls.add(c.getString(c.getColumnIndex("fname")).toString());
//                                   String ename = c.getString(c.getColumnIndex("ename"));
//                                   String fname = c.getString(c.getColumnIndex("fname"));
//
//                                   arraylist.add("Name :" + ename + "\n" + "Age :" + fname + "\n");
//
//                               } while (c.moveToNext());
//                           }
//
//                       }
//
//                   } catch (Exception e) {
//                       e.printStackTrace();
//                   }
//             ArrayAdapter<String> adp=new ArrayAdapter<String>(showAllActivity.this, R.layout.support_simple_spinner_dropdown_item,arraylist);
//
////               adapter = new ArrayAdapter<String>(this, R.layout.list_item, R.id.product_name,);
//               lv.setAdapter(adp);
//
//
//
//
////               Cursor c;
////               c=obj.populateListview(s.toString());
////               if(c != null && !c.isClosed())
////               {
////                   c.moveToFirst();
////                   do{
////                       ls.add(c.getString(c.getColumnIndex("ename")).toString());
////                       fls.add(c.getString(c.getColumnIndex("fname")).toString());
////                       String ename = c.getString(c.getColumnIndex("ename"));
////                       String fname = c.getString(c.getColumnIndex("fname"));
////                       arraylist.add("Name :" + ename + " " + "Age :" + fname + "\n");
////                   }while (c.moveToNext());
////                   ArrayAdapter<String> adp=new ArrayAdapter<String>(showAllActivity.this, R.layout.support_simple_spinner_dropdown_item,arraylist);
////                   lv.setAdapter(adp);
////               }
////               else
////               {
////                   Toast.makeText(getApplicationContext(),"No Data", Toast.LENGTH_LONG).show();
////               }
//
//           }
//
//
//
//           @Override
//           public void afterTextChanged(Editable editable) {
//
//           }
//       });
//        Cursor c;
//        c=obj.get_Data();
//        if(c != null && !c.isClosed())
//        {
//            c.moveToFirst();
//            do{
//                ls.add(c.getString(c.getColumnIndex("ename")).toString());
//                fls.add(c.getString(c.getColumnIndex("fname")).toString());
//            }while (c.moveToNext());
//            ArrayAdapter<String> adp=new ArrayAdapter<>(this, R.layout.support_simple_spinner_dropdown_item, ls);
//            lv.setAdapter(adp);
//        }
//        else
//        {
//            Toast.makeText(getApplicationContext(),"No Data", Toast.LENGTH_LONG).show();
//        }
       lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
           @Override
           public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
               Intent intent = new Intent(showAllActivity.this,UpdateActivity.class);
               intent.putExtra("Data",ls.get(position));
               intent.putExtra("Data1",fls.get(position));
               startActivity(intent);
           }
       });
    }
}
package com.example.crud_priya;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class dbo extends SQLiteOpenHelper {
    public dbo(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, "name1", factory, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table emptb(eid integer primary key autoincrement, ename text,fname text)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        onCreate(db);
    }
    public void add_Data(String name,String fname)
    {
        SQLiteDatabase db = this.getWritableDatabase(); //open db
        ContentValues cv = new ContentValues(); //class for insert
//        String fs1name="ythgrfd";
//        String fsname="trfds";

        cv.put("ename",name);
        cv.put("fname",fname);
        db.insert("emptb",null,cv);
        db.close();
    }

    public Cursor get_Data()
    {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from emptb",null);
        return res;
    }

    public void up_rec(String oldName,String name,String fname)
    {

        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("ename",name);
        cv.put("fname",fname);
        db.update("emptb", cv, "ename = ?", new String[]{oldName});
        db.close();
    }

    public void del_rec(String oldName)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        db.delete("emptb", "ename = ?", new String[]{oldName});
        db.close();
    }
    public Cursor populateListview(String s) {
        SQLiteDatabase db=this.getWritableDatabase();
        Cursor c1 = db.rawQuery("select * from emptb where ename = ?",new String[]{s} );
        return c1;
    }

}

package com.example.patient_tracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class dbo extends SQLiteOpenHelper {
//    Context context;
    public dbo(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, "patientdb2", factory, version);
//        this.context=context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
//        db.execSQL("create table Register(uid integer primary key autoincrement, uname text,upassword text)");
        db.execSQL("create table patienttb(pid integer primary key autoincrement, pemail text,ppassword text,pname text,pdisease text,pmedication text,pdate text,pcost text)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
//        db.execSQL("create table patienttb(pid integer primary key autoincrement, pname text,pdisease text,pmedication text,pdate text,pcost text)");

//        db.execSQL("drop table if exists Register");
        db.execSQL("drop table if exists patienttb");
        onCreate(db);
    }
    public boolean login(String uname1, String upassword1) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("select * from patienttb where pemail = ? and ppassword = ?",new String[]{uname1,upassword1});

        if(c.getCount() <= 0) {
            c.close();
            db.close();
            return false;
        } else {
            c.close();
            db.close();
            return true;
        }
    }

//    public void add_register()
//    {
//        SQLiteDatabase db = this.getWritableDatabase(); //open db
//        ContentValues cv = new ContentValues(); //class for insert
//        String user="radhika@gmail.com";
//        String pass="radhika";
//
//        cv.put("uname",user);
//        cv.put("upassword",pass);
//
//        db.insert("Register",null,cv);
//        db.close();
//    }
    public void add_patient(String pemail,String ppassword,String pname,String pdisease,String pmedication,String pdate,String pcost)
//    public void add_patient()
    {
        SQLiteDatabase db = this.getWritableDatabase(); //open db
        ContentValues cv = new ContentValues(); //class for insert


//        String name="radhika";
//        String disease="fever";
//        String medication="radhika";
//        String date="fever";
//        String cost="radhika";

        cv.put("pemail",pemail);
        cv.put("ppassword",ppassword);
        cv.put("pname",pname);
        cv.put("pdisease",pdisease);
        cv.put("pmedication",pmedication);
        cv.put("pdate",pdate);
        cv.put("pcost",pcost);

        db.insert("patienttb",null,cv);
        db.close();
    }

    public Cursor get_Data()
    {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from patienttb",null);
        return res;
    }

//    public void up_rec(String oldName,String name,String fname)
//    {
//
//        SQLiteDatabase db=this.getWritableDatabase();
//        ContentValues cv=new ContentValues();
//        cv.put("ename",name);
//        cv.put("fname",fname);
//        db.update("emptb", cv, "ename = ?", new String[]{oldName});
//        db.close();
//    }
//
//    public void del_rec(String oldName)
//    {
//        SQLiteDatabase db=this.getWritableDatabase();
//        db.delete("emptb", "ename = ?", new String[]{oldName});
//        db.close();
//    }
}

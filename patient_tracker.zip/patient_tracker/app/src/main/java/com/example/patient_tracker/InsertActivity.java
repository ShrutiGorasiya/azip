package com.example.patient_tracker;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.Calendar;

public class InsertActivity extends AppCompatActivity {
    Button submitres;
    EditText name,email,pass,doa,cost,meditation,disease;
//    Spinner txtcity;
    public String text;
    int mDate,mMonth,mYear;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert2);
        submitres=findViewById(R.id.submitres);
        name = findViewById(R.id.name);
        email = findViewById(R.id.email);
        pass = findViewById(R.id.pass);
        doa = findViewById(R.id.doa);
        cost=findViewById(R.id.cost);
        disease=findViewById(R.id.disease);
        meditation=findViewById(R.id.meditation);
//        txtcity = findViewById(R.id.spinnerCity);

        dbo obj = new dbo(getApplicationContext(),null,null,1);
        doa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Calendar cal = Calendar.getInstance();
                mDate = cal.get(Calendar.DATE);
                mMonth = cal.get(Calendar.MONTH);
                mYear = cal.get(Calendar.YEAR);
                DatePickerDialog datePickerDialog = new DatePickerDialog(InsertActivity.this, android.R.style.Theme_DeviceDefault_Light_Dialog, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int month, int date) {
                        doa.setText(date+"/"+month+"/"+year);
                    }
                },mYear,mMonth,mDate);
                datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis()-1000);
                datePickerDialog.show();
            }
        });
      submitres.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {
              obj.add_patient(email.getText().toString(),pass.getText().toString(),name.getText().toString(),disease.getText().toString(),meditation.getText().toString(),doa.getText().toString(),cost.getText().toString());
              Toast.makeText(getApplicationContext(),"Data Inserted", Toast.LENGTH_LONG).show();
//              textv.getText().clear();
//              textfname.getText().clear();
              startActivity(new Intent(InsertActivity.this,MainActivity.class));

          }
      });
    }
}
package com.example.productapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class ProductPage extends AppCompatActivity {

    Dbo obj=new Dbo(this,null,null,1);

    TextView tid,tNm,tPr,tCat;

    Button bEdit,bDelete;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_page);

        tid=findViewById(R.id.tpid);
        tid.setEnabled(false);
        tNm=findViewById(R.id.tpnm);
        tPr=findViewById(R.id.tprc);
        tCat=findViewById(R.id.tpcat);
        bEdit=findViewById(R.id.bEdit);
        bDelete=findViewById(R.id.bDelete);

        Intent i3=this.getIntent();

        tid.setText(i3.getStringExtra("pid"));
        tNm.setText(i3.getStringExtra("pnm"));
        tPr.setText(i3.getStringExtra("pprice"));
        tCat.setText(i3.getStringExtra("pcat"));


        bEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String msg="";
                if(!tNm.getText().toString().isEmpty() && !tPr.getText().toString().isEmpty() && !tCat.getText().toString().isEmpty()){

                    obj.edit(Integer.parseInt(tid.getText().toString()),tNm.getText().toString(),Integer.parseInt(tPr.getText().toString().trim()),tCat.getText().toString());

                    msg="Record Updated";
                    Toast.makeText(getApplicationContext(),msg,Toast.LENGTH_SHORT).show();
                    finish();

                }else{
                    msg="Provide details";
                }
                Toast.makeText(getApplicationContext(),msg,Toast.LENGTH_SHORT).show();

            }
        });

        bDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                obj.delete(Integer.parseInt(tid.getText().toString()));

                Toast.makeText(getApplicationContext(),"Deleted",Toast.LENGTH_SHORT).show();
                finish();

            }
        });

    }
}
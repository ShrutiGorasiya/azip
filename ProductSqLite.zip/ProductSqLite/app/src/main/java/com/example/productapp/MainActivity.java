package com.example.productapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    Dbo obj=new Dbo(this,null,null,1);

    TextView tNm,tPr,tCat;
    Button bAdd;

    ListView list;
    ArrayList<String> arrayList;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tNm=findViewById(R.id.tnm);
        tPr=findViewById(R.id.tprice);
        tCat=findViewById(R.id.tcat);
        bAdd=findViewById(R.id.bAdd);
        list=findViewById(R.id.list1);

        showData();

        bAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String msg="";
                if(!tNm.getText().toString().isEmpty() && !tPr.getText().toString().isEmpty() && !tCat.getText().toString().isEmpty()){

                    obj.add(tNm.getText().toString(),Integer.parseInt(tPr.getText().toString()),tCat.getText().toString());

                    msg="Record Added";
                    showData();

                    tNm.setText("");
                    tPr.setText("");
                    tCat.setText("");

                }else{
                    msg="Provide details";
                }
                Toast.makeText(getApplicationContext(),msg,Toast.LENGTH_SHORT).show();
            }
        });

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                String info=((TextView) view).getText().toString();

                String[] pro=info.split("   ");

                if(pro.length==4 && !pro[0].equals("ID")){
                    Intent i1=new Intent(getApplicationContext(),ProductPage.class);

                    i1.putExtra("pid",pro[0]);
                    i1.putExtra("pnm",pro[1]);
                    i1.putExtra("pprice",pro[2]);
                    i1.putExtra("pcat",pro[3]);

                    startActivity(i1);

                }

            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();
        showData();
    }

    public void showData(){

        arrayList=new ArrayList<String>();
        adapter=new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item,arrayList);

        list.setAdapter(adapter);

        arrayList.add("ID   NAME    PRICE   CATEGORY");
        Cursor res=obj.getAll();

        if(res.moveToFirst()){
            do{
                arrayList.add(res.getString(0)+"    "+res.getString(1)+"    "+res.getString(2)+"    "+res.getString(3));
            }while(res.moveToNext());
        }

    }
}
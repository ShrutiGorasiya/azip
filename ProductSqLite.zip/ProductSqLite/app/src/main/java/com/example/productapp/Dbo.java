package com.example.productapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class Dbo extends SQLiteOpenHelper {

    public Dbo(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, "ProductDb", factory, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        sqLiteDatabase.execSQL("create table product(pid integer primary key autoincrement,pname text,price int,category text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("drop table if exists product");
        onCreate(sqLiteDatabase);
    }

    public void add(String pnm,int price,String cat){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("pname",pnm);
        cv.put("price",price);
        cv.put("category",cat);
        db.insert("product",null,cv);
        db.close();
    }

    public void edit(Integer pid,String pnm,int price,String cat){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("pname",pnm);
        cv.put("price",price);
        cv.put("category",cat);
        db.update("product",cv,"pid=?",new String[]{Integer.toString(pid)});
        db.close();
    }

    public void delete(Integer pid){
        SQLiteDatabase db=this.getWritableDatabase();
        db.delete("product","pid=?",new String[]{Integer.toString(pid)});
        db.close();
    }

    public Cursor getAll(){
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor res=db.rawQuery("select *from product",null);
        return res;
    }
}
